/*
   COPYRIGHT (C) 2023 Michael Meniru. All rights reserved.
   CSI project
   Author.  Michael Meniru 4807562
   Version. 1.01 12/08/2023
*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <limits>  // numeric_limits<std::streamsize> for validations

using std::cout;
using std::endl;
using std::cin;
using std::ifstream;

const int FLOOR_ARRAY_SIZE = 5;
const int ROOM_ARRAY_SIZE = 8;

//	Transfers are represented by a �T�.
//	The Check outs are represented by a �C�.
//	Nurse work stations are represented by a �W�.
//	Occupied rooms are represented by an asterisk �O�.
//	A vacant room is represented by a blank �V�.
//	The utility rooms are represented by an �X�.

const char VACANT = 'V';
const char CHECKOUT = 'C';
const char OCCUPIED = 'O';
const char NURSE_STATION = 'W';
const char TRANSFER = 'T';
const char UTILITY = 'X';
const char INVALID = '@';

// These functions will work in their current form. You must use them. You may add functions but
// don't remove them. Complete the pre and post condition comments.

//Function prototypes
/*
printGrid takes a two dimensional char array and displays its contents
Precondition: a two dimensional Char array and its two sizes
Postcondition: console output of the grid with char values the correspond to room types
*/
void printGrid(const char hospitalFloors[FLOOR_ARRAY_SIZE][ROOM_ARRAY_SIZE]);

/*
//Reads in the initial grid from Beds.txt file and converts all of the values into the corresponding room codes
//Precondition: the text document and a char array
//Postcondition: the char array is filled with the corresponding values
*/
void readGrid(char hospitalFloors[FLOOR_ARRAY_SIZE][ROOM_ARRAY_SIZE]);


/*
goes through a char array and replaces any checkouts with vacants
Precondition: a char array of patients
Postcondition: a char array of patients without checkouts
*/
void checkOuts(char hospitalFloors[FLOOR_ARRAY_SIZE][ROOM_ARRAY_SIZE]);

/*
Perform the transfers and build the dynamic array of pointers. This function also will compute the available number of rooms
Precondition: two dimensional char array with sizes using a global variable and a reference integer
Postcondition: the transfers are occupy the closest vacant spots and the integer is changed to the number of vacancies
while the function returns a pointer to pointer char array of addresses of vacant spots
*/
char** tranfers(char hospitalFloors[FLOOR_ARRAY_SIZE][ROOM_ARRAY_SIZE], int &);

/*
Perform the new patient adds passing the new patient input from
the nurse station and passing the dynamic array of vacancies count for updating
Precondition: integer for number of patients to add and number of vacant spots left as well
as a pointer to pointer char array
Postcondition: Patients are put into vacant slots
*/
void newPatient(int, int &, char **);

/*
 Prompts the user and uses input validation to get the number of patients added
 It returns the nurse station choice, passes the current vacancies.
 Precondition: integer for vacancies
 Postcondition: the integer of rooms to be occupied
*/
int newPatientInput(int);


int main()///Int Main is Located Here!
{
    char hospitalFloors[FLOOR_ARRAY_SIZE][ROOM_ARRAY_SIZE] = {};
    int input = 0;
    int vacantSpots = 0;

    // CODE HERE and FUNCTIONS GO AFTER MAIN
    // THIS SHOULD BE PRIMARILY FUNCTION CALLS
    readGrid(hospitalFloors);

    checkOuts(hospitalFloors);
    char ** vacancyList = tranfers(hospitalFloors,vacantSpots);


    do
    {
        input = newPatientInput(vacantSpots);
        newPatient(input,vacantSpots,vacancyList);
        printGrid(hospitalFloors);
    } while (vacantSpots > 0);

    cout << " *** No more rooms are available today *** " << endl;

    delete vacancyList;
    return 4;
}

// FUNCTIONS GO HERE

void printGrid(const char hospitalFloors[FLOOR_ARRAY_SIZE][ROOM_ARRAY_SIZE])
{
    cout << "----------------------" << endl;
    for (int i = 0; i < FLOOR_ARRAY_SIZE; i++)
    {
        for (int j = 0; j < ROOM_ARRAY_SIZE; j++)
        {
            switch(hospitalFloors[i][j])
            {
            case VACANT:
                cout << VACANT << " ";
                break;
            case CHECKOUT:
                cout << CHECKOUT << " ";
                break;
            case OCCUPIED:
                cout << OCCUPIED << " ";
                break;
            case NURSE_STATION:
                cout << NURSE_STATION << " ";
                break;
            case TRANSFER:
                cout << TRANSFER << " ";
                break;
            case UTILITY:
                cout << UTILITY << " ";
                break;
            default:
                cout << INVALID << " ";
                break;
            }
        }
        cout << endl;
    }
    cout << "----------------------" << endl;
}

void readGrid(char hospitalFloors[FLOOR_ARRAY_SIZE][ROOM_ARRAY_SIZE])
{
    ifstream bedsText;
    int roomIdentifier = 0;
    bedsText.open("Beds1.txt");
    if (!bedsText)
    {
        cout << "Document could not be found!" << endl;
    }
    else
    {
            for (int i = 0; i < FLOOR_ARRAY_SIZE; i++)
            {
                for (int j = 0; j < ROOM_ARRAY_SIZE; j++)
                {
                    if (bedsText.eof())
                    {
                        return;
                    }
                    bedsText >> roomIdentifier;
                    switch (roomIdentifier)
                    {
                        case 0:
                            hospitalFloors[i][j] = VACANT;
                            break;
                        case 1:
                            hospitalFloors[i][j] = CHECKOUT;
                            break;
                        case 2:
                            hospitalFloors[i][j] = OCCUPIED;
                            break;
                        case 3:
                            hospitalFloors[i][j] = NURSE_STATION;
                            break;
                        case 4:
                            hospitalFloors[i][j] = TRANSFER;
                            break;
                        case 5:
                            hospitalFloors[i][j] = UTILITY;
                            break;
                        default:
                            hospitalFloors[i][j] = INVALID;
                            break;
                    }
                }
            }
    }
    printGrid(hospitalFloors);
    bedsText.close();
    cout << "Grid loaded" << endl;
}

void checkOuts(char hospitalFloors[FLOOR_ARRAY_SIZE][ROOM_ARRAY_SIZE])
{
 for (int i = 0; i < FLOOR_ARRAY_SIZE; i++)
    {
        for (int j = 0; j < ROOM_ARRAY_SIZE; j++)
        {
            if(hospitalFloors[i][j] == CHECKOUT)
            {
                hospitalFloors[i][j] = VACANT;
            }
        }
    }
}

char** tranfers(char hospitalFloors[FLOOR_ARRAY_SIZE][ROOM_ARRAY_SIZE], int &numberOfVacantRooms)
{
 for (int i = FLOOR_ARRAY_SIZE-1; i >= 0; i--)
    {
        for (int j = ROOM_ARRAY_SIZE; j >= 0; j--)
        {
            if(hospitalFloors[i][j] == TRANSFER)
            {
                bool flag = true;
                int k = FLOOR_ARRAY_SIZE;
                while (flag && (k >= 0))
                    {
                        int l = ROOM_ARRAY_SIZE;
                        while (flag && (l >= 0))
                        {
                            if(hospitalFloors[k][l] == VACANT)
                            {
                                hospitalFloors[i][j] = VACANT;
                                hospitalFloors[k][l] = OCCUPIED;
                                flag = false;
                            }
                            l--;
                        }
                        k--;
                    }
            }
        }
    }
int vacancyCount = 0;
char ** vacancies = new char* [40];//This is so scuffed
for (int i = 0; i < FLOOR_ARRAY_SIZE; i++)
    {
        for (int j = 0; j < ROOM_ARRAY_SIZE; j++)
        {
            if(hospitalFloors[i][j] == VACANT)
            {
                vacancies[vacancyCount] = &hospitalFloors[i][j];
                vacancyCount++;

            }
        }
    }

    printGrid(hospitalFloors);
    cout << "Check outs and Transfers completed" << endl;
    //what pointer to pointer char is this used for?
    numberOfVacantRooms = vacancyCount;
    return vacancies;
}

void newPatient(int input, int &vacancies, char **vacanciesList)
{
    int i = 0;
    while ((vacancies >= 1)&&(i < input))
    {
        bool flag = true;
        int j = vacancies - 1;
        while((flag)&&(j >= 0))
        {
            if (*vacanciesList[j] == VACANT)
            {
                *vacanciesList[j] = OCCUPIED;
                flag = false;
                vacancies --;
            }
            j++;
        }
        i++;
    }

}

int newPatientInput(int vacancies)
{
    int addPatients = 0;
    while (1)
    {
    cout << "Please enter the number of new patients, from one up to " << vacancies << ": ";
    cin >> addPatients;

    if (cin.fail())
    {
        cout << endl << "That's not even a number!" << endl;
        cin.clear();
        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    else if (addPatients < 0)
    {
        cout << endl << "What?! You can't remove patients!" << endl;
        cin.clear();
        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    else if (addPatients == 0)
    {
        cout << endl << "Please enter a positive number." << endl;
        cin.clear();
        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    else if (addPatients > vacancies)
    {
       cout << endl << "That's too many" << endl;
        cin.clear();
        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    else
    {
        return addPatients;
    }
    }
}

/* Just in case anything goes wrong
char** tranfers(char hospitalFloors[FLOOR_ARRAY_SIZE][ROOM_ARRAY_SIZE], int &numberOfVacantRooms)
{
 for (int i = 0; i < FLOOR_ARRAY_SIZE; i++)
    {
        for (int j = 0; j < ROOM_ARRAY_SIZE; j++)
        {
            if(hospitalFloors[i][j] == TRANSFER)
            {
                bool flag = true;
                int k = 0;
                while (flag && (k < FLOOR_ARRAY_SIZE))
                    {
                        int l = 0;
                        while (flag && (l < ROOM_ARRAY_SIZE))
                        {
                            if(hospitalFloors[k][l] == VACANT)
                            {
                                hospitalFloors[i][j] = VACANT;
                                hospitalFloors[k][l] = OCCUPIED;
                                flag = false;
                            }
                            l++;
                        }
                        k++;
                    }
            }
        }
    }
int vacancyCount = 0;
char ** vacancies = new char* [40];//This is so scuffed
for (int i = 0; i < FLOOR_ARRAY_SIZE; i++)
    {
        for (int j = 0; j < ROOM_ARRAY_SIZE; j++)
        {
            if(hospitalFloors[i][j] == VACANT)
            {
                vacancies[vacancyCount] = &hospitalFloors[i][j];
                vacancyCount++;

            }
        }
    }

    printGrid(hospitalFloors);
    cout << "Check outs and Transfers completed" << endl;
    //what pointer to pointer char is this used for?
    //return an array of vacancy
}
*/


