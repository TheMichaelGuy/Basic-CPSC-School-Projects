#include "mystack.h"

//constructor for myStack
template class MyStack<int>;//this is so that there is a defined reference for using this with the int
template <class T>
MyStack<T>::MyStack(int size)
{
    stackArray = new T [size];
    stackSize = size;
    numElem = -1;
}

//copy constructor for myStack
template <class T>
MyStack<T>::MyStack(const MyStack &r)
{
    if (r.stackSize > 0)
    {
        stackArray = new T[r.stackSize];
    }
    else
    {
        stackArray = nullptr;
    }
    stackSize = r.stackSize;

    for (int i = 0; i < stackSize; i++)
    {
        stackArray[i] = r.stackArray[i];
    }

    numElem = r.numElem;
}

//assignment operator for myStack
template <class T>
MyStack<T>& MyStack<T>::operator=(const MyStack &r)
{
    if (this==&r)
    {
        return *this;
    }

    delete [] stackArray;

    if (r.stackSize > 0)
    {
        stackArray = new T[r.stackSize];
    }
    else
    {
        stackArray = nullptr;
    }
    stackSize = r.stackSize;

    for (int i = 0; i < stackSize; i++)
    {
        stackArray[i] = r.stackArray[i];
    }

    numElem = r.numElem;

    return *this;
}

//destructor
template <class T>
MyStack<T>::~MyStack()
{
    delete [] stackArray;
}

//push
template <class T>
void MyStack<T>::push(T item)
{
    if (isFull())
    {
        std::cout << "The stack is full." << std::endl;
    }
    else
    {
        ++numElem;
        stackArray[numElem] = item;
    }
}

//pop
template <class T>
T MyStack<T>::pop()
{
    T item;
    if (isEmpty())
    {
        std::cout << "The stack is empty" << std::endl;
    }
    else
    {
        item = stackArray[numElem];
        --numElem;
    }
    return item;
}

//top
template <class T>
T MyStack<T>::top()
{
    if(isEmpty())
    {
        return 0;//hmm
    }
    return stackArray[numElem];
}

//isFull
template <class T>
bool MyStack<T>::isFull() const
{
    if (numElem == stackSize - 1)
    {
        return true;
    }
    return false;
}

//isEmpty
template <class T>
bool MyStack<T>::isEmpty() const
{
    if (numElem == -1)
    {
        return true;
    }
    return false;
}

//size
template <class T>
int MyStack<T>::size() const
{
    return numElem + 1;
}
