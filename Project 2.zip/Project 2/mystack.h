#ifndef MYSTACK_H
#define MYSTACK_H

//***************************************//
//static stack template                  //
//finish all functions                   //
//***************************************//

#include <iostream>
using namespace std;

template <class T>
class MyStack
{
private:
   T *stackArray;  // Pointer to the stack array
   int stackSize;    // The stack size
   int numElem;		//index of the top element in the stack array

public:
   // Constructor
   //precondition: an integer and a stack class with defined variables for an array, size, and top
   //postcondition: a stack of the size provided

   MyStack(int);	//pass in an int: tells the maximum size of the stack

   // Copy constructor
   //precondition: an already created stack
   //postcondition: another stack is constructed with the same values
   MyStack(const MyStack &);

   //operator= overloading
   //precondition: two stacks
   //postcondition: the stack on the left is turned into the stack on the right
   MyStack& operator=(const MyStack &);

   // Destructor
   //precondition: a stack
   //postcondition: not a stack (it's gone)
   ~MyStack();

   // Stack operations

   //push
   //appends an item to the end of the stack and shifts the top pointer
   //precondition: a stack of the type of the item to be inserted and an item to be inserted
   //postcondition: a stack with a new element added to the top
   void push(T);	//add an item to the stack by passing in a value

   //pop
   //removes the element at the top of the list
   //precondition: a stack that you want to remove the first element of
   //postcondition: a stack that no longer has that blemish of an element
   T pop();	//pop a value out by returning the value

   //top
   //returns the element at the top of a list or 0 if the list is empty
   //precondition: a stack that has an element... or not
   //postcondition: the item that the element at the top is is returned
   T top();	//return the value at the top position in the stack

   //isFull
   //true or false on whether the stack array is full
   //precondition: a stack
   //postcondition: the VERDICT (true or false)
   bool isFull() const;	//tell if the stack is full

   //isEmpty
   //true or false on whether the stack array is empty
   //precondition: a stack
   //postcondition: the VERDICT (true or false)
   bool isEmpty() const;	//tell if the stack is empty

   //size
   //returns the number of pushed elements in the stack (not the max capacity)
   //precondition: the stack (properly defined with a size variable)
   //postcondition: its size
   int size() const;	//tell how many items are in the stack
};

//YOUR CODE
//......

#endif
