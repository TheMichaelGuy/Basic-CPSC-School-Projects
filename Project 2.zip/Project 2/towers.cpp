#include <iostream>
#include "towers.h"
#include "mystack.h"

using namespace std;
//YOUR CODE
//......

//constructor
Towers::Towers(int number)
{
    peg1 = new MyStack<int>(numDisk);
    peg2 = new MyStack<int>(numDisk);
    peg3 = new MyStack<int>(numDisk);
    numDisk = number;
}

//destructor
Towers::~Towers()
{
    delete peg1;
    delete peg2;
    delete peg3;
}

//copy constructor
Towers::Towers(const Towers &r)
{
    if (r.numDisk > 0)
    {
        peg1 = new MyStack<int>(r.numDisk);
        peg2 = new MyStack<int>(r.numDisk);
        peg3 = new MyStack<int>(r.numDisk);

        *peg1 = *(r.peg1);
        *peg2 = *(r.peg2);
        *peg3 = *(r.peg3);
    }
    else
    {
        peg1 = nullptr;
        peg2 = nullptr;
        peg3 = nullptr;
    }
    numDisk = r.numDisk;
}

//assignment operator
Towers& Towers::operator=(const Towers &r)
{
    if (this==&r)
    {
        return *this;
    }
    delete peg1;
    delete peg2;
    delete peg3;

    if (r.numDisk > 0)
    {
        peg1 = new MyStack<int>(r.numDisk);
        peg2 = new MyStack<int>(r.numDisk);
        peg3 = new MyStack<int>(r.numDisk);

        *peg1 = *(r.peg1);
        *peg2 = *(r.peg2);
        *peg3 = *(r.peg3);
    }
    else
    {
        peg1 = nullptr;
        peg2 = nullptr;
        peg3 = nullptr;
    }
    numDisk = r.numDisk;

    return *this;
}

//setDisks
void Towers::setDisks()
{

    for(int i = 0; i < numDisk; ++i)
    {
       peg1->push(numDisk-i);
    }

    plotPegs();
}

//move
void Towers::move(int n, MyStack<int>* s, MyStack<int>* t, MyStack<int>* d)
{
    //determine which disk to move
    //should put all of the logic in here
    //this is where the recursive stuff starts going off
    if (n > 0)//Base case
    {
        move(n - 1,s,d,t);//Recursion
        moveOne(s,d);
        move(n - 1,t,s,d);//Recursion
    }
}

//moveOne
void Towers::moveOne(MyStack<int>* s, MyStack<int>* d)
{
    d->push(s->pop());
    plotPegs(); //better to display after every action
}





//display disks on the three pegs in the console window (stdout)
//DO NOT MODIFY THIS FUNCTION
void Towers::plotPegs()
{


  	if (peg1==NULL || peg2==NULL || peg3==NULL) return;

	int n1=peg1->size();
	int n2=peg2->size();
	int n3=peg3->size();
	int numDisk = n1+n2+n3;

	MyStack<int> tmp1(*peg1);
	MyStack<int> tmp2(*peg2);
	MyStack<int> tmp3(*peg3);

	//plot
	for (int i=0; i<numDisk; i++) {
		//peg1
		if (numDisk-n1-i>0) {
			for (int j=0; j<numDisk; j++)
				cout << " ";
		}
		else {
			int m1 = tmp1.top();
			tmp1.pop();
			for (int j=0; j<m1; j++)
				cout << "*";
			for (int j=m1; j<numDisk; j++)
				cout << " ";
		}
		cout <<" | ";

		//peg2
		if (numDisk-n2-i>0) {
			for (int j=0; j<numDisk; j++)
				cout << " ";
		}
		else {
			int m2 = tmp2.top();
			tmp2.pop();
			for (int j=0; j<m2; j++)
				cout << "*";
			for (int j=m2; j<numDisk; j++)
				cout << " ";
		}
		cout <<" | ";

		//peg3
		if (numDisk-n3-i>0) {
			for (int j=0; j<numDisk; j++)
				cout << " ";
		}
		else {
			int m3 = tmp3.top();
			tmp3.pop();
			for (int j=0; j<m3; j++)
				cout << "*";
			for (int j=m3; j<numDisk; j++)
				cout << " ";
		}
		cout<<endl;
	}
	cout << "_________________________________________\n";
}
