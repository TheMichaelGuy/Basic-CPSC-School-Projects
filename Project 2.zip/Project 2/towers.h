#ifndef TOWERS_H
#define TOWERS_H

#include "mystack.h"

//********************************//
//prototype of class tower        //
//put all functions to towers.cpp //
//DO NOT MODIFY THIS FILE         //
//********************************//

class Towers {
	private:
		MyStack<int> *peg1; //start stack
		MyStack<int> *peg2; //tmp stack
		MyStack<int> *peg3; //destination stack
		int numDisk;	//number of discs to move
	public:
		//constructor, passing in an int to tell how many discs to move
		//creates a set of towers that are the height of the integer provided
        //precondition: a defined stack array named my stack and an integer
        //postcondition: a set of towers
		Towers(int);

		//destructor
		//deletes the towers to free up memory
        //precondition: a Towers object
        //postcondition: one less Towers object
		~Towers();

		//copy constructor
		//creates a set of Towers by copying another set of Towers
        //precondition: an already defined Towers object and stack array
        //postcondition: two identical towers
		Towers(const Towers &);

	    //operator= overloading
	    //turns a Towers object into an identical copy of another object
        //precondition: a Tower as a parameter and a defined stack array and a Tower to be modified
        //postcondition: two identical Towers objects
	    Towers& operator=(const Towers &);

	    //start function, DO NOT MODIFY
		void start() {
			setDisks();
			move(numDisk, peg1, peg2, peg3);
		}

	private:
	    //setDisks
	    //puts the disks into the first peg
        //precondition: an empty Towers object and a stack definition
        //postcondition: a Towers with the disks in one peg
		void setDisks();	//initialize start-tower by putting discs in, then print out the status of three towers after initialized


		void plotPegs();	//print out the status of three towers

		//move
		//uses a recursive algorithm to move the disks while
        //following the rules of the Towers of Hanoi
        //precondition: a defined stack class and a set of Towers with a set of disks
        //postcondition: a sequence of the tower being solved displayed on screen
		void move(int n, MyStack<int>* s, MyStack<int>* t, MyStack<int>* d); //move n discs from tower s to tower d by using a temporary tower t

		//moveOne
        //moves a peg from s to d
        //precondition: a set of towers and a completely defined stack class
        //postcondition: a disk from tower s is moved to tower d
		void moveOne(MyStack<int>* s, MyStack<int>* d);  //move one discs from tower s to tower d
};
#endif
