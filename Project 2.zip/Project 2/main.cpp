// towerofhanoi.cpp : Defines the entry point for the console application.
//DO NOT MODIFY THIS FILE

#include <iostream>
#include "towers.h"
#include "mystack.h"

using namespace std;

int main()
{
	int numDisk = 4;//replacing this number is fun
	Towers t(numDisk);
	t.start();
	return 0;
}

